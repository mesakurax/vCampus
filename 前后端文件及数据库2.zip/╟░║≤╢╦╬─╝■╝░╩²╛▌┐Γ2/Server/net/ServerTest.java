package net;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.sql.SQLException;

public class ServerTest {
    public static void main(String[] args) throws SQLException, IOException, ClassNotFoundException {
        int  port=8081;
        ServerSocket serverSocket = new ServerSocket(port);
        System.out.println("服务端已启动，等待客户端连接...");

        while (true) {
            Socket socket = serverSocket.accept();
            System.out.println("客户端已连接，地址：" + socket.getInetAddress());
            // 获取输入流和输出流
            ObjectInputStream inputStream = new ObjectInputStream(socket.getInputStream());
            ObjectOutputStream outputStream = new ObjectOutputStream(socket.getOutputStream());

            SocketHelper s00000 = new SocketHelper();
            s00000.setSocket(socket);
            s00000.setIs(inputStream);
            s00000.setOs(outputStream);

            int result=s00000.getIs().readInt();

            System.out.println("00000");
            if(result==1) {

                System.out.println("开始开始开始");
                result=s00000.getIs().readInt();
                if(result==9090) {
                    LoginModelServer l22 = new LoginModelServer(s00000);
                    l22.LoginHandler();
                }
                result=s00000.getIs().readInt();
                if(result==9191) {
                    System.out.println("进入主模块");
                    UsersMainModelServer u222 = new UsersMainModelServer(s00000);
                    u222.UsersMainHandler();
                }
                System.out.println("结束用户");

            }



        }
    }

}
