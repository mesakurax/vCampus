package database;

import java.sql.SQLException;
import java.util.HashMap;

import common.User;

public interface UserDao {
    //验证登录接口，int类型，-1登陆失败，1管理员登陆，2非管理员登录
    User login(User user) throws SQLException;
    boolean insert(User user) throws SQLException;
    boolean delete(String uid) throws SQLException;
    //修改学生信息
    boolean update(User usertemp) throws SQLException;
    boolean updateB(User usertemp) throws SQLException;

    //查询学生信息
    User select(String uid) throws SQLException;


    HashMap<Integer, User> searchAll() throws SQLException;
}
