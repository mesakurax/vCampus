package clientui;

import common.User;

import javax.swing.*;
import javax.swing.event.TableModelEvent;
import javax.swing.event.TableModelListener;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import java.awt.*;
import java.awt.event.*;
import java.util.HashMap;
import java.util.Vector;

public class MainUI extends JFrame {

    //背景图片
    private ImageIcon img;
    //背景标签
    private JLabel background;
    //背景面板
    private JPanel jp;

    //文本框
    private TextField t;


    //表格组件
    private Vector<Vector<String>> vData;// 数据行向量集，因为列表不止一行，往里面添加数据行向量，添加方法add(row)
    private Vector<String> vName ;// 列名（标题）向量，使用它的add()方法添加列名
    private JTable  jTable1;//表格
    private  JScrollPane scroll;//滚动面包，扩大范围
    private DefaultTableModel model; //新建一个默认数据模型


    //框架大小
    private int WIDTH;
    private int HEIGHT;

    //表格内容物
    public HashMap<Integer, User> users;

    //操作相关
    public  int opercode;//操作码
    public boolean isfinished;//操作是否完成




    public MainUI()
    {

        //操作相关初设
        opercode=-1;
        isfinished=false;

        //初设users
        users = new HashMap<Integer, User>();

        //框架初设
        WIDTH=1685;
        HEIGHT=1030;


        //添加图片
        img = new ImageIcon("D:\\ideaproject\\vCampusServicewyj\\UIimage\\image0.jpg"); //添加图片
        setBak(); //调用背景方法
        Container c = getContentPane(); //获取JFrame面板
        jp = new JPanel(); //创建个JPanel
        jp.setOpaque(false);
        //把JPanel设置为透明 这样就不会遮住后面的背景 这样能在JPanel随意加组件
        c.add(jp);
        setBounds(0,0,WIDTH,HEIGHT);
        setVisible(true);
        //JPanel布局缺省
        jp.setLayout(null);



        //新建按钮
        JButton button1=new JButton ("查询全部");
        JButton button2=new JButton ("用户查询");
        JButton button3=new JButton ("添加用户");
        //JButton button4=new JButton ("修改用户");
        JButton button5=new JButton ("删除用户");

        //新建文本框
        t=new TextField();

        //按钮美化
        button1.setContentAreaFilled(false);
        button1.setBorder(BorderFactory.createRaisedBevelBorder());
        Font f=new Font("华文行楷",Font.BOLD,20);//根据指定字体名称、样式和磅值大小，创建一个新 Font。
        button1.setFont(f);
        button1.setFocusPainted(false);

        //文本框美化
        t.setFont(new Font("隶书", Font.PLAIN, 30));//设置字体颜色和大小,font.plain字体普通
        t.setVisible(true);


        //为按钮设置命令
        button1.setActionCommand("查询全部");
        button2.setActionCommand("用户查询");
        button3.setActionCommand("添加用户");
        //button4.setActionCommand("修改用户");
        button5.setActionCommand("删除用户");


        //按钮位置大小设置;
        button1.setBounds(0,50,100,50);
        button2.setBounds(380,875,100,50);
        button3.setBounds(0,110,100,50);
        //button4.setBounds(0,170,100,50);
        button5.setBounds(510,875,100,50);

        //文本框设置大小位置
        t.setBounds(150,880,200,40);


        //设置监听
        MyListener lis=new MyListener();
        button1.addActionListener(lis);
        button2.addActionListener(lis);
        button3.addActionListener(lis);
        //button4.addActionListener(lis);
        button5.addActionListener(lis);

        //添加按钮
        jp.add(button1);
        jp.add(button2);
        jp.add(button3);
        //jp.add(button4);
        jp.add(button5);

        //添加文本框
        jp.add(t);




        //表格组件初设
        iniTable();
        //设置表格
        setTable();



        //表格监听
        jTable1.getModel().addTableModelListener(new TableModelListener(){

            public void tableChanged(TableModelEvent e) {
                if(e.getType() == TableModelEvent.UPDATE){

                    int row=jTable1.getEditingRow();
                    int col=jTable1.getEditingColumn();
                    //System.out.println("更改对象："+vData.get(row).get(col) );
                    User utemp=new User();
                    utemp.setId(vData.get(row).get(0));
                    utemp.setName(vData.get(row).get(1));
                    utemp.setPassword(vData.get(row).get(2));
                    utemp.setSex(vData.get(row).get(3));
                    utemp.setAge(Integer.parseInt(vData.get(row).get(4)));
                    utemp.setOccupation(vData.get(row).get(5));
                    utemp.setAcademy(vData.get(row).get(6));
                    //utemp.UserPrint();


                    //储存前清空操作对象
                    clearUsers();
                    //存储对象
                    addUser(utemp);
                    //完成操作
                    opercode=4;
                    isfinished=true;





                }

            }

        });

        //窗口等比放大
        addComponentListener(new ComponentAdapter() {//拖动窗口监听
            public void componentResized(ComponentEvent e) {
                int width=getWidth();//获取窗口宽度
                int height=getHeight();//获取窗口高度

                //面板比例设置
                jp.setBounds(0,0,width,height);

                //按钮比例设置
                int w=jp.getWidth();
                int h=jp.getHeight();
                button1.setBounds(0,50*h/HEIGHT,100*w/WIDTH,50*h/HEIGHT);
                button2.setBounds(380*w/WIDTH,875*h/HEIGHT,100*w/WIDTH,50*h/HEIGHT);
                button3.setBounds(0,110*h/HEIGHT,100*w/WIDTH,50*h/HEIGHT);
                //button4.setBounds(0,170*h/HEIGHT,100*w/WIDTH,50*h/HEIGHT);
                button5.setBounds(510*w/WIDTH,875*h/HEIGHT,100*w/WIDTH,50*h/HEIGHT);

                //图片
                img.setImage(img.getImage().getScaledInstance(w, h,Image.SCALE_DEFAULT ));

                //标签
                background.setBounds(0,0,w,h);
            }


        });

        //窗口关闭监听
        addWindowListener(new WindowAdapter() {
            //关闭窗口
            @Override
            public void windowClosing(WindowEvent e) {
                opercode=-2;
                isfinished=true;
            }
        });


    }

    //设置主背景
    public void setBak(){
        ((JPanel)this.getContentPane()).setOpaque(false);
        //图片适应标签大小
        img.setImage(img.getImage().getScaledInstance(WIDTH, HEIGHT,Image.SCALE_DEFAULT ));
        //创建背景标签
        background = new  JLabel(img);
        this.getLayeredPane().add(background, new Integer(Integer.MIN_VALUE));
        background.setBounds(0, 0, WIDTH, HEIGHT);
    }
    //表格组件初设
    public void iniTable()
    {
        vData = new Vector<Vector<String>>(); // 数据行向量集，因为列表不止一行，往里面添加数据行向量，添加方法add(row)
        vName = new Vector<String>(); // 列名（标题）向量，使用它的add()方法添加列名
        jTable1 = new JTable();
        jTable1.setRowHeight(50);
        model = new DefaultTableModel(vData,vName); //新建一个默认数据模型
        scroll = new JScrollPane();//新建滚动面板
        //建立表头
        vName.add(0,"工号/一卡通号");
        vName.add(1,"姓名");
        vName.add(2,"密码");
        vName.add(3,"性别");
        vName.add(4,"年龄");
        vName.add(5,"职业");
        vName.add(6,"学院");

        //滑动面板位置设置
        scroll.setBounds(120,50,1500,800);
        //表头设置
        JTableHeader tab_header = jTable1.getTableHeader();					//获取表头
        tab_header.setFont(new Font("微软雅黑", Font.PLAIN, 15));
        tab_header.setPreferredSize(new Dimension(tab_header.getWidth(), 30));	//修改表头的高度
        jTable1.setFont(new Font("微软雅黑", Font.PLAIN, 13));

        model.setDataVector(vData,vName);//新建一个数据模型
        System.out.println("bbbbbbbbb");
        jTable1.setModel(model);
        System.out.println("oooooo");
        scroll.setViewportView(jTable1);
        System.out.println("nnnnnn");
        jp.add(scroll);


    }
    //设置表格
    public void setTable()
    {
        vData.clear();
        for(int times=1;times<=users.size();times++) {


            Vector vRow=new Vector();
            vRow.add(0, users.get(times).getId());
            vRow.add(1, users.get(times).getName());
            vRow.add(2, users.get(times).getPassword());
            vRow.add(3,users.get(times).getSex());
            vRow.add(4,  Integer.toString(users.get(times).getAge()));
            vRow.add(5, users.get(times).getOccupation());
            vRow.add(6, users.get(times).getAcademy());
            vData.add(vRow);


        }
        scroll.setViewportView(jTable1);
        System.out.println("..............");


    }

    //添加表格内容物
    public void addUser(User utemp)
    {
        users.put(users.size()+1,utemp);
    }

    //清空Users
    public void clearUsers()
    {
        users.clear();
    }

    //操作恢复默认
    public void operReset()
    {
        opercode=0;
        isfinished=false;
    }




    /*
   public static void main(String[] args)
   {
       MainUI ui=new MainUI();
       System.out.println("opop: "+ui.users.size());
     // for(int i=1;i<=10;i++)
     // {
     // User u=new User();
     // ui.addUser(u);
      //}
       ui.setTable();

   }
     */




    //自定义监听类
    class MyListener implements ActionListener
    {
        @Override
        public void actionPerformed(ActionEvent e) {
            // System.out.println("aaa");
            if(e.getActionCommand().equals("查询全部"))
            {
               opercode=1;
               isfinished=true;
            }
            else if(e.getActionCommand().equals("添加用户"))
            {
                opercode=2;
            }
            else if(e.getActionCommand().equals("用户查询"))
            {
                if(!t.getText().isEmpty())
                {
                    User u=new User();
                    u.setId(t.getText());
                    addUser(u);
                    //清除文本
                    t.setText(" ");
                    opercode=3;
                    isfinished=true;
                    System.out.println(e.getActionCommand());
                }
            }

            else if(e.getActionCommand().equals("删除用户"))
            {
                if(!t.getText().isEmpty())
                {
                    User u=new User();
                    u.setId(t.getText());
                    addUser(u);

                    //清除文本
                    t.setText(" ");
                    opercode=5;
                    isfinished=true;
                    System.out.println(e.getActionCommand());
                }
            }

        }
    }



}


