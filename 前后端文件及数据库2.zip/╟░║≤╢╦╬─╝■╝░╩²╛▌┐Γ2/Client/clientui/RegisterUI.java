package clientui;

import common.User;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class RegisterUI  extends Frame {
    private User utemp;
    private boolean isfinished;
    public User getUser()
    {
        return utemp;
    }
    public void close()
    {
        setVisible(false);
    }

    public boolean getResult()
    {
        return isfinished;
    }
    public void setResult(boolean temp)
    {
        isfinished=temp;
    }

    //盘端是否放弃，即用户点击叉号
    public boolean isgiveup;
    public RegisterUI()
    {

        isgiveup=false;
        //设置初始用户
        utemp=new User();
        isfinished=false;

        setVisible(true);
        //布局缺省
        setLayout((null));
        //设置按钮
        JButton button1=new JButton ("确认");
        button1.setBounds(150,360,100,40);
        //设置标签
        JLabel l1=new JLabel("工号/一卡通号");
        JLabel l2=new JLabel("姓名");
        JLabel l3=new JLabel("密码");
        JLabel l4=new JLabel("职业");
        JLabel l5=new JLabel("学院");
        JLabel l6=new JLabel("性别");
        JLabel l7=new JLabel("年龄");

        l1.setBounds(70,50,100,30);
        l2.setBounds(70,90,100,30);
        l3.setBounds(70,130,100,30);
        l4.setBounds(70,170,100,30);
        l5.setBounds(70,210,100,30);
        l6.setBounds(70,250,100,30);
        l7.setBounds(70,290,100,30);


        //设置文本框
        TextField t1=new TextField();
        TextField t2=new TextField();
        TextField t3=new TextField();
        //下拉选项
        JComboBox<String> t4=new JComboBox<>();
        t4.addItem("教师");// 下拉框列表添加内容。Item（条款，项）
        t4.addItem("学生");

        //TextField t4=new TextField();
        TextField t5=new TextField();
        TextField t6=new TextField();
        TextField t7=new TextField();

        t1.setBounds(170,50,120,30);
        t2.setBounds(170,90,120,30);
        t3.setBounds(170,130,120,30);
        t4.setBounds(170,170,120,30);
        t5.setBounds(170,210,120,30);
        t6.setBounds(170,250,120,30);
        t7.setBounds(170,290,120,30);
        //添加组件
        add(t1);
        add(l1);
        add(t2);
        add(l2);
        add(t3);
        add(l3);
        add(t4);
        add(l4);
        add(t5);
        add(l5);
        add(t6);
        add(l6);
        add(t7);
        add(l7);
        add(button1);
        //监听按钮
        button1.addActionListener(new ActionListener() {
        public void actionPerformed(ActionEvent evt) {
            utemp.setId(t1.getText());
            utemp.setName(t2.getText());
            utemp.setPassword(t3.getText());
            utemp.setOccupation((String)t4.getSelectedItem());
            utemp.setAcademy(t5.getText());
            utemp.setSex(t6.getText());
            utemp.setAge((Integer.valueOf(t7.getText()).intValue()));
            utemp.UserPrint();
            isfinished=true;
            setVisible(false);
            t1.setText("");
            t2.setText("");
            t3.setText("");
            t5.setText("");
            t6.setText("");
            t7.setText("");

        }
    });
      //设置窗口
        setBounds(700,200,400,600);
        addWindowListener(new WindowAdapter() {
            //关闭窗口
            @Override
            public void windowClosing(WindowEvent e) {
                //System.exit(0);
                setVisible(false);

            }
        });


        //关闭监听
        addWindowListener(new WindowAdapter() {
            //关闭窗口
            @Override
            public void windowClosing(WindowEvent e) {
                isgiveup=true;
                isfinished=true;
                setVisible(false);
            }
        });

    }
    //public static void main(String[] args)
    //{
    //    new RegisterUI();
    //}



}
