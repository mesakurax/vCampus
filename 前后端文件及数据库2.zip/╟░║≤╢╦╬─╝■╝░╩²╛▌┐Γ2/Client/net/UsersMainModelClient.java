package net;

import clientui.LoginUI;
import clientui.MainUI;
import clientui.PasswordChange;
import clientui.RegisterUI;
import common.User;
import operation.Operation;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;

public class UsersMainModelClient {

    private static ObjectOutputStream outputStream ;
    private static ObjectInputStream inputStream ;
    private static Operation oper;
    private static User utemp;
    private static User none;

    //SocketHelper
    private static SocketHelper socket;


    //主界面查询全部函数
    public static boolean searchAll(MainUI ui) throws IOException, ClassNotFoundException {

        //实例化操作对象
        oper.operClear();
        System.out.println("808080");
        oper.setOperationcode(003);
        // 向服务端发送对象
        outputStream.reset();
        outputStream.writeObject(oper);
        outputStream.flush();
        System.out.println("对象发送成功");

        // 读取服务端发送的响应对象
        oper.copy((Operation) inputStream.readObject());
        System.out.println("对象读取成功");
        System.out.println("服务端响应的oper对象：");
        if (oper.getSuccess()) {

            System.out.println("全部查询成功");
            //清空ui数据
            ui.clearUsers();
            //向ui复制数据
            for(int i=1;i<=oper.getUsers().size();i++)
            {

                ui.addUser(oper.getUser(i));
            }

            return true;

        } else {
            System.out.println("全部查询失败");
            return false;
        }
    }

    //查询一个
    public static boolean searchOne(MainUI ui) throws IOException, ClassNotFoundException {

        //实例化操作对象
        oper.operClear();
        //设置操作码
        oper.setOperationcode(004);
        //存储查询用户ID
        oper.addUser(ui.users.get(1));
        // 向服务端发送对象
        outputStream.reset();
        outputStream.writeObject(oper);
        outputStream.flush();
        System.out.println("对象发送成功");

        // 读取服务端发送的响应对象
        oper.copy((Operation) inputStream.readObject());
        System.out.println("对象读取成功");
        System.out.println("服务端响应的oper对象：");
        if (oper.getSuccess()) {

            System.out.println("查询成功");
            //清空ui数据
            ui.clearUsers();
            System.out.println("size; "+oper.getUsers().size());
            //向ui复制数据
            oper.getUser(1).UserPrint();
            ui.addUser(oper.getUser(1));

            return true;

        } else {
            System.out.println("查询失败");
            return false;
        }
    }
    //删除一个
    public static boolean deleteOne(MainUI ui) throws IOException, ClassNotFoundException {

        //实例化操作对象
        oper.operClear();
        //设置操作码
        oper.setOperationcode(005);
        //存储查询用户ID
        oper.addUser(ui.users.get(1));
        // 向服务端发送对象
        outputStream.reset();
        outputStream.writeObject(oper);
        outputStream.flush();
        System.out.println("对象发送成功");

        // 读取服务端发送的响应对象
        oper.copy((Operation) inputStream.readObject());
        System.out.println("对象读取成功");
        System.out.println("服务端响应的oper对象：");
        if (oper.getSuccess()) {

            System.out.println("删除成功");
            //清空ui数据
            ui.clearUsers();

            return true;

        } else {
            System.out.println("删除失败");
            return false;
        }
    }

    //更新一个
    public static boolean updateOne(MainUI ui) throws IOException, ClassNotFoundException {

        //实例化操作对象
        oper.operClear();
        //设置操作码
        oper.setOperationcode(006);
        //存储查询用户ID
        oper.addUser(ui.users.get(1));
        // 向服务端发送对象
        outputStream.reset();
        outputStream.writeObject(oper);
        outputStream.flush();
        System.out.println("对象发送成功");

        // 读取服务端发送的响应对象
        oper.copy((Operation) inputStream.readObject());
        System.out.println("对象读取成功");
        System.out.println("服务端响应的oper对象：");
        if (oper.getSuccess()) {

            System.out.println("更新成功");
            //清空ui数据
            ui.clearUsers();

            return true;

        } else {
            System.out.println("更新失败");
            return false;
        }
    }

    public static boolean register(RegisterUI ui) throws IOException, ClassNotFoundException {

        utemp.copy(ui.getUser());
        //实例化操作对象
        oper.operClear();
        oper.addUser(utemp);
        System.out.println("808080");
        oper.getUser(1).UserPrint();
        oper.setOperationcode(002);
        // 向服务端发送对象
        outputStream.reset();
        outputStream.writeObject(oper);
        outputStream.flush();
        System.out.println("对象发送成功");

        // 读取服务端发送的响应对象
        oper.copy((Operation) inputStream.readObject());
        System.out.println("对象读取成功");
        System.out.println("服务端响应的oper对象：");
        if (oper.getSuccess()) {

            System.out.println("注册成功111111");

            ui.close();
            return true;

        } else {
            System.out.println("注册失败111111");
            return false;
        }
    }


    //终止函数,结束两端服务
    public static void termination() throws IOException {
        //实例化操作对象
        oper.operClear();
        System.out.println("89898989");
        oper.setOperationcode(-1);
        // 向服务端发送对象
        outputStream.reset();
        outputStream.writeObject(oper);
        outputStream.flush();
        System.out.println("终止对象发送成功");
    }

    //构造函数
    public UsersMainModelClient(SocketHelper stemp)
    {
        //初始化sockethelper
        socket=stemp;
        //无实际意义
        none=new User();
        //设置操作，用户
        oper=new Operation();
        utemp= new User();

    }

    //获取SocketHelper
    public SocketHelper getSocketHelper()
    {
        return socket;
    }

    public static  void UsersMainoper() throws IOException, ClassNotFoundException {
        //设置输入输出
        outputStream =socket.getOs();
        inputStream =socket.getIs();

        //建立注册界面备用
        RegisterUI ui2=new RegisterUI();
        ui2.setVisible(false);

        //设置主模块是否完成
        boolean isMF=false;
        //新建主界面
        MainUI um=new MainUI();
        //主模块循环体
        while(!isMF)
        {
            //自旋等待用户完成功能选择
            while (um.opercode == -1) {
                //无实际意义
                none.setId("id");
            }
            //读取操作
            //查询全部
            if(um.opercode==1)
            {
                if(searchAll(um))
                {
                    //System.out.println("opoppopopopp: "+um.users.size());
                    um.setTable();
                }
                //重置操作
                um.operReset();
                //清空数据
                um.clearUsers();
            }
            //添加用户
            else if(um.opercode==2)
            {
                //与主界面无关了
                //重置操作
                um.operReset();
                //清空数据
                um.clearUsers();

                //打开注册界面
                ui2.setVisible(true);
                System.out.println("666666");
                //自旋等待用户完成输入或放弃
                while (!ui2.getResult()) {
                    //无实际意义
                    none.setId("id");
                }
                //用户放弃注册
                if(ui2.isgiveup)
                {
                    System.out.println("gur");
                    //重置注册界面
                    ui2.setResult(false);
                    ui2.isgiveup = false;
                    //下一次循环
                    continue;
                }
                boolean regresult=register(ui2);
                //重置注册界面
                ui2.setResult(false);
            }
            //单个查询
            else if(um.opercode==3)
            {
                //查询成功，设置表格
                if(searchOne(um))
                {
                    System.out.println("正在绘制表格");
                    um.setTable();
                }
                //重置操作
                um.operReset();
                //清空数据
                um.clearUsers();
            }
            else if(um.opercode==4)
            {
                updateOne(um);
                //重置操作
                um.operReset();
                //清空数据
                um.clearUsers();
            }
            //删除用户
            else if(um.opercode==5)
            {
                deleteOne(um);
                //重置操作
                um.operReset();
                //清空数据
                um.clearUsers();
            }
            else if(um.opercode==-2)
            {
                termination();
                isMF=true;
                //重置操作
                um.operReset();
                //清空数据
                um.clearUsers();
            }
        }


    }


}

