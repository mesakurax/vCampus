package net;

import java.io.IOException;

public class clientTest {
    public static void main(String[] args) throws IOException, ClassNotFoundException {
        SocketHelper socketHelper111=new SocketHelper();
        socketHelper111.getConnection("localhost", 8081);

        socketHelper111.getOs().reset();
        socketHelper111.getOs().writeInt(1);
        socketHelper111.getOs().flush();
       System.out.println("ppppppp");

        socketHelper111.getOs().reset();
        socketHelper111.getOs().writeInt(9090);
        socketHelper111.getOs().flush();

        LoginModelClient l1111=new LoginModelClient(socketHelper111);
        l1111.LoginOper();
        System.out.println("当前登录成功的用户是： ");
        l1111.getUrecord().UserPrint();


        socketHelper111.getOs().reset();
        socketHelper111.getOs().writeInt(9191);
        socketHelper111.getOs().flush();
        UsersMainModelClient m11=new UsersMainModelClient(socketHelper111);
        m11.UsersMainoper();

        System.out.println("结束用户");

    }
}
