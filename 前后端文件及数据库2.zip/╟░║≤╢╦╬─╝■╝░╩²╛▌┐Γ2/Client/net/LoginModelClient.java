package net;

import clientui.LoginUI;
import clientui.PasswordChange;
import clientui.RegisterUI;
import common.User;
import operation.Operation;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;


public class LoginModelClient {

    private static ObjectOutputStream outputStream ;
    private static ObjectInputStream inputStream ;

    //操作类
    private static Operation oper;
    //中转用户
    private static User utemp;
    //无意义
    private static User none;
    //存储登陆对象
    private static  User urecord;
    //SocketHelper
    private static SocketHelper socket;

    public User getUrecord()
    {
        return urecord;
    }
    //登录函数
    public static boolean login(LoginUI ui) throws IOException, ClassNotFoundException {


        //自旋等待用户完成输入
        while (!ui.getResult()) {
            //无实际意义
            none.setId("id");
        }
        utemp.copy(ui.getUser());
        //实例化操作对象
        oper.operClear();
        oper.addUser(utemp);
        oper.setOperationcode(001);
        // 向服务端发送对象
        System.out.println("登录对象");
        ui.getUser().UserPrint();
        //utemp.UserPrint();
        //oper.getUser(1).UserPrint();
        outputStream.reset();
        outputStream.writeObject(oper);
        outputStream.flush();
        System.out.println("对象发送成功");

        // 读取服务端发送的响应对象
        oper.copy((Operation)inputStream.readObject());
        System.out.println("对象读取成功");
        System.out.println("服务端响应的oper对象：");
        if (oper.getSuccess()) {

            urecord.copy(oper.getUser(1));
            System.out.println("登录成功111111");
            //关闭UI
            ui.close();

            return true;

        } else {
            System.out.println("登录失败111111");

            return false;
        }
    }
    //注册函数
    public static boolean register(RegisterUI ui) throws IOException, ClassNotFoundException {

        utemp.copy(ui.getUser());
        //实例化操作对象
        oper.operClear();
        oper.addUser(utemp);
        System.out.println("808080");
        oper.getUser(1).UserPrint();
        oper.setOperationcode(002);
        // 向服务端发送对象
        outputStream.reset();
        outputStream.writeObject(oper);
        outputStream.flush();
        System.out.println("对象发送成功");

        // 读取服务端发送的响应对象
        oper.copy((Operation) inputStream.readObject());
        System.out.println("对象读取成功");
        System.out.println("服务端响应的oper对象：");
        if (oper.getSuccess()) {

            System.out.println("注册成功111111");

            ui.close();
            return true;

        } else {
            System.out.println("注册失败111111");
            return false;
        }
    }
    //修改密码
    public static boolean passwordChange(PasswordChange ui) throws IOException, ClassNotFoundException {

        utemp.copy(ui.getUser());
        User newuser= new User();
        newuser.copy(ui.getNewuser());
        System.out.println("id: "+utemp.getId()+" p: "+utemp.getPassword());
        //实例化操作对象
        oper.operClear();
        oper.addUser(utemp);
        oper.addUser(newuser);
        oper.setOperationcode(007);
        // 向服务端发送对象
        outputStream.reset();
        outputStream.writeObject(oper);
        outputStream.flush();
        System.out.println("对象发送成功");

        // 读取服务端发送的响应对象
        oper.copy((Operation) inputStream.readObject());
        System.out.println("对象读取成功");
        System.out.println("服务端响应的oper对象：");
        if (oper.getSuccess()) {

            System.out.println("修改成功111111");

            ui.close();
            return true;

        } else {
            System.out.println("修改失败111111");
            return false;
        }
    }
    //终止函数,结束两端服务
    public static void termination() throws IOException {
        //实例化操作对象
        oper.operClear();
        System.out.println("89898989");
        oper.setOperationcode(-1);
        // 向服务端发送对象
        outputStream.reset();
        outputStream.writeObject(oper);
        outputStream.flush();
        System.out.println("终止对象发送成功");
    }


    //执行登录操作
    public static  void LoginOper() throws IOException, ClassNotFoundException {
        //设置登录模块是否完成
        boolean isLogin=false;

        //建立注册界面备用
        RegisterUI ui2=new RegisterUI();
        ui2.setVisible(false);

        //建立修改密码界面备用
        PasswordChange ui3=new PasswordChange();
        ui3.setVisible(false);

        //设置输入输出
        outputStream =socket.getOs();
        inputStream =socket.getIs();

        //新建登录界面
        LoginUI ui=new LoginUI();

        //循环直至完成登录
        while(!isLogin) {

            System.out.println("2222222222");



            //自旋等待用户完成功能选择
            while (ui.getOperation() == -1) {
                //无实际意义
                none.setId("id");
            }


            System.out.println("333333333");



            //用户选择登录
            if(ui.getOperation()==0) {

                System.out.println("444444444");

                //登录操作
                isLogin = login(ui);
                //重置登录界面选择
                ui.setOperation(-1);
                ui.setResult(false);
                //
            }
            //用户选择注册
            else if(ui.getOperation()==1){

                System.out.println("555555555");
                //打开注册界面
                ui2.setVisible(true);
                System.out.println("666666");
                //自旋等待用户完成输入或放弃
                while (!ui2.getResult()) {
                    //无实际意义
                    none.setId("id");
                }
                //用户放弃注册
                if(ui2.isgiveup)
                {
                    System.out.println("gur");
                    //重置注册界面
                    ui2.setResult(false);
                    ui2.isgiveup = false;
                    //重置登录界面选择
                    ui.setOperation(-1);
                    //下一次循环
                    continue;
                }
                boolean regresult=register(ui2);
                //重置注册界面
                ui2.setResult(false);
                //重置登录界面选择
                ui.setOperation(-1);


            }
            //修改密码
            else if(ui.getOperation()==2){

                //打开修改界面
                ui3.setVisible(true);

                //自旋等待用户完成输入或放弃
                while (!ui3.getResult()) {
                    //无实际意义
                    none.setId("id");
                }
                //用户放弃注册
                if(ui3.isgiveup)
                {
                    System.out.println("guc");
                    //重置修改界面
                    ui3.setResult(false);
                    ui3.isgiveup = false;
                    ui3.setOperation(-1);
                    //重置登录界面选择
                    ui.setOperation(-1);
                    //下一次循环
                    continue;
                }
                boolean regresult=passwordChange(ui3);
                //重置修改界面
                ui3.setResult(false);
                ui3.isgiveup = false;
                ui3.setOperation(-1);
                //重置登录界面选择
                ui.setOperation(-1);


            }
            else{
                termination();
                System.out.println("客户端终止");
                System.exit(0);
            }
        }

        System.out.println("登录对象如下：");
        urecord.UserPrint();
        System.out.println("进入主模块");


    }

    //构造函数
    public LoginModelClient(SocketHelper stemp)
     {
     //初始化sockethelper
     socket=stemp;
     //创建存储对象
     urecord=new User();
     //无实际意义
     none=new User();
     //设置操作，用户
     oper=new Operation();
     utemp= new User();
 }
    //获取sockethelper
    public SocketHelper getSocketHelper()
    {
        return socket;
    }

}

