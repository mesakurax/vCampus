package clientui;

import common.User;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class PasswordChange extends Frame {
    private User utemp;
    private User unew;

    private JButton button1;
    private TextField textField;
    private JPasswordField textField2;
    private JPasswordField textField3;


    private int operation;//判断用户的操作类型登录or注册,-1未选操作
    private boolean isfinished;//判断当前用户是否完成输入

    public boolean isgiveup;//判断是否放弃

    public User getUser()
    {
        return utemp;
    }

    public User getNewuser()
    {
        return unew;
    }
    public boolean getResult()
    {
        return isfinished;
    }
    public void setResult(boolean temp)
    {
        isfinished=temp;
    }
    public void close()
    {
        setVisible(false);
    }

    public int getOperation()
    {
        return operation;
    }
    public void setOperation(int temp)
    {
        operation=temp;
    }
    public PasswordChange()
    {

        utemp=new User();
        unew=new User();
        operation=-1;
        isfinished=false;
        isgiveup=false;
        //设置窗体大小和位置
        setBounds(700,300,400,400);
        //按钮
        button1= new JButton("修改密码");
        button1.setActionCommand("修改密码");
        //标签
        JLabel lab = new JLabel("用户名");
        JLabel lab2 = new JLabel("旧密码");
        JLabel lab3 = new JLabel("新密码");
        //输入框
        textField=new TextField();
        textField2=new JPasswordField();
        textField3=new JPasswordField();
        //布局缺省
        setLayout(null);
        //添加组件
        add(textField);
        add(textField2);
        add(textField3);
        add(lab);
        add(lab2);
        add(lab3);
        add(button1);
        //大小位置设定
        lab.setBounds(100,150,40,20);
        lab2.setBounds(100,190,40,20);
        lab3.setBounds(100,230,40,20);
        textField.setBounds(160,150,80,20);
        textField2.setBounds(160,190,80,20);
        textField3.setBounds(160,230,80,20);
        button1.setBounds(150,370,100,20);



        //按钮设置监听
        PasswordChange.MyListener1 lis1=new PasswordChange.MyListener1();
        button1.addActionListener(lis1);


        //设置缩放监听
        addComponentListener(new ComponentAdapter() {//拖动窗口监听
            public void componentResized(ComponentEvent e) {
                int w=getWidth();//获取窗口宽度
                int h=getHeight();//获取窗口高度

                //组件比例设置
                lab.setBounds(100*w/400,150*h/400,40*w/400,20*h/400);
                lab2.setBounds(100*w/400,190*h/400,40*w/400,20*h/400);
                lab3.setBounds(100*w/400,230*h/400,40*w/400,20*h/400);
                textField.setBounds(160*w/400,150*h/400,80*w/400,20*h/400);
                textField2.setBounds(160*w/400,190*h/400,80*w/400,20*h/400);
                textField3.setBounds(160*w/400,230*h/400,80*w/400,20*h/400);
                button1.setBounds(150*w/400,370*h/400,100*w/400,20*h/400);




            }

        });



        //设置frame可见性
        setVisible(true);
        //退出监听
        addWindowListener(new WindowAdapter() {
            //关闭窗口
            @Override
            public void windowClosing(WindowEvent e) {
                operation=2;
                isgiveup=true;
                isfinished=true;
            }
        });
        //pack();
    }

    //监听子类
    class MyListener1 implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            operation=1;
            String id=textField.getText();
            String op=textField2.getText();
            String np=textField3.getText();
            utemp.setId(id);
            utemp.setPassword(op);
            unew.setId(id);
            unew.setPassword(np);
            textField.setText("");
            textField2.setText("");
            textField3.setText("");
            isfinished=true;


        }
    }
   // public static void main(String[] args)
   // {
        //new PasswordChange();
    //}

}
