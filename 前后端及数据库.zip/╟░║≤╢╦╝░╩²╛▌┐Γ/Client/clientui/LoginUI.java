package clientui;

import common.User;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class LoginUI extends Frame {
    private User utemp;
    private JButton button1;
    private JButton button2;
    private JButton button3;
    private TextField textField;
    private JPasswordField textField2;


    int operation;//判断用户的操作类型登录or注册,-1未选操作，0登录，1注册.
    Boolean isfinished;//判断当前用户是否完成输入,

    public User getUser()
    {
        return utemp;
    }
    public boolean getResult()
    {
        return isfinished;
    }
    public void setResult(boolean temp)
    {
        isfinished=temp;
    }
    public void close()
    {
        setVisible(false);
    }

    public int getOperation()
    {
        return operation;
    }
    public void setOperation(int temp)
    {
        operation=temp;
    }
    public LoginUI()
    {

        utemp=new User();
        operation=-1;
        isfinished=false;
        //设置窗体大小和位置
        setBounds(700,300,400,400);
        //按钮
       button1= new JButton("登录");
       button2= new JButton("注册");
        button3= new JButton("修改密码");
        button1.setActionCommand("登录");
        button2.setActionCommand("注册");
        button3.setActionCommand("修改密码");
        //标签
        JLabel lab = new JLabel("用户名");
        JLabel lab2 = new JLabel("密码");
        //输入框
        textField=new TextField();
        textField2=new JPasswordField();
        //布局缺省
        setLayout(null);
        //添加组件
        add(textField);
        add(textField2);
        add(lab);
        add(lab2);
        add(button1);
        add(button2);
        add(button3);
        //大小位置设定
        lab.setBounds(100,150,40,20);
        lab2.setBounds(100,190,40,20);
        textField.setBounds(160,150,80,20);
        textField2.setBounds(160,190,80,20);
        button2.setBounds(330,370,60,20);
        button1.setBounds(10,370,60,20);
        button3.setBounds(150,370,100,20);



        //按钮设置监听
        MyListener1 lis1=new MyListener1();
        button1.addActionListener(lis1);
        button2.addActionListener(lis1);
        button3.addActionListener(lis1);


        //设置缩放监听
        addComponentListener(new ComponentAdapter() {//拖动窗口监听
            public void componentResized(ComponentEvent e) {
                int w=getWidth();//获取窗口宽度
                int h=getHeight();//获取窗口高度

                //组件比例设置
                lab.setBounds(100*w/400,150*h/400,40*w/400,20*h/400);
                lab2.setBounds(100*w/400,190*h/400,40*w/400,20*h/400);
                textField.setBounds(160*w/400,150*h/400,80*w/400,20*h/400);
                textField2.setBounds(160*w/400,190*h/400,80*w/400,20*h/400);
                button2.setBounds(330*w/400,370*h/400,60*w/400,20*h/400);
                button1.setBounds(10*w/400,370*h/400,60*w/400,20*h/400);
                button3.setBounds(150*w/400,370*h/400,100*w/400,20*h/400);




            }

        });



        //设置frame可见性
        setVisible(true);
        //退出监听
        addWindowListener(new WindowAdapter() {
            //关闭窗口
            @Override
            public void windowClosing(WindowEvent e) {
                operation=-2;
                isfinished=true;
            }
        });
        //pack();
    }

    //监听子类
    class MyListener1 implements ActionListener
    {
        @Override
        public void actionPerformed(ActionEvent e) {
            if(e.getActionCommand().equals("登录"))
            {
            utemp.setId(textField.getText());
            utemp.setPassword(textField2.getText());
            System.out.println("登录对象： ");
            utemp.UserPrint();
            operation=0;
            isfinished=true;
            textField.setText("");
            textField2.setText("");
            System.out.println("登录");
            }
            else  if(e.getActionCommand().equals("注册"))
            {
                //弹出注册界面

                operation=1;
                //System.out.println("注册"+operation);
            }
            else
            {
                //密码修改界面
                operation=2;
            }

        }
    }
   // public static void main(String[] args)
   // {
       // new LoginUI();
   // }
}


