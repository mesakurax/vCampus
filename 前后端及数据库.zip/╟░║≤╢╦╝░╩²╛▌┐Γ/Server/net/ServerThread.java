package net;
import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.sql.SQLException;

import common.User;
import operation.Operation;
import database.UserDao_Imp;
public class ServerThread extends Thread{

    private Socket socket;
    private Operation operresult;
    public void login(User utemp) throws SQLException {


             //操作读取完毕清空
            operresult.operClear();
            //实例化数据库操作对象
            UserDao_Imp daotemp=new UserDao_Imp();
            //登录操作
            User u=daotemp.login(utemp);
            if(u!=null)
            {
                operresult.addUser(u);
                operresult.setSuccess(true);
            }



    }
    public void register(User utemp) throws SQLException {

        //操作读取完毕清空
        operresult.operClear();
        //实例化数据库操作对象
        UserDao_Imp daotemp = new UserDao_Imp();
        //登录操作
        boolean result = daotemp.insert(utemp);
        if (result) {
            operresult.setSuccess(true);
        }
    }


    public void researchAll() throws SQLException {

        //实例化数据库操作对象
        UserDao_Imp daotemp = new UserDao_Imp();
       //查询全部操作
        operresult.setUsers(daotemp.searchAll());
        if(!operresult.getUsers().isEmpty())
        {
            operresult.setSuccess(true);
        }
    }
    public void researchOne(User utemp) throws SQLException {

        //操作读取完毕清空
        operresult.operClear();
        //实例化数据库操作对象
        UserDao_Imp daotemp = new UserDao_Imp();
        System.out.println("kkkkkkkkk: "+utemp.getId());
        //查询一个操作
        User u=daotemp.select(utemp.getId());

        if(u!=null)
        {
            operresult.addUser(u);
            operresult.setSuccess(true);
        }
    }
    public void deleteOne(User utemp) throws SQLException {

        //操作读取完毕清空
        operresult.operClear();
        //实例化数据库操作对象
        UserDao_Imp daotemp = new UserDao_Imp();
        //删除一个操作
        if(daotemp.delete(utemp.getId()))
        {

            operresult.setSuccess(true);
        }
    }
    public void updateOne(User utemp) throws SQLException {

        //操作读取完毕清空
        operresult.operClear();
        //实例化数据库操作对象
        UserDao_Imp daotemp = new UserDao_Imp();
        //删除一个操作
        if(daotemp.update(utemp))
        {

            operresult.setSuccess(true);
        }
    }
    public void passwordChange(User utemp,User unew) throws SQLException {

        //操作读取完毕清空
        operresult.operClear();
        //实例化数据库操作对象
        UserDao_Imp daotemp = new UserDao_Imp();
        //删除一个操作
        if(daotemp.login(utemp)!=null)
        {

             System.out.println("登录成功090909");
            if(daotemp.updateB(unew))
            {
                System.out.println("修改成功090909");
                operresult.setSuccess(true);
            }
        }
    }


    public ServerThread(Socket socket) {
        this.socket = socket;
    }

    @Override
    public void run() {

        //实例化操作
         operresult=new Operation();
        //用户是否退出
        boolean isfinished=false;
            try {

                // 获取输入流和输出流
                ObjectInputStream inputStream = new ObjectInputStream(socket.getInputStream());
                ObjectOutputStream outputStream = new ObjectOutputStream(socket.getOutputStream());
                //
                while (!isfinished) {
                    System.out.println("4545454545");

                    // 读取客户端发送的对象
                    operresult.copy((Operation)inputStream.readObject());
                    System.out.println("接受用户端对象");
                    System.out.println("编号： "+operresult.getOperationcode());


                    //获取操作

                    if (operresult.getOperationcode() == 001) {
                        System.out.println("登录");
                        //登录操作
                        login(operresult.getUser(1));
                        // 向客户端发送响应数据
                        outputStream.reset();
                        outputStream.writeObject(operresult);
                        //重置操作
                        operresult.operClear();
                        // 清理资源
                        outputStream.flush();
                    } else if (operresult.getOperationcode() == 002) {
                        System.out.println("注册");
                        //注册操作
                        System.out.println("909090");
                        register(operresult.getUser(1));
                        // 向客户端发送响应数据
                        outputStream.reset();
                        outputStream.writeObject(operresult);
                        //重置操作
                        operresult.operClear();
                        // 清理资源
                        outputStream.flush();
                    }
                    //查询全部
                    else if (operresult.getOperationcode() == 003) {
                        System.out.println("查询全部");
                        //操作读取完毕，清空
                        operresult.operClear();
                        researchAll();
                        // 向客户端发送响应数据
                        outputStream.reset();
                        outputStream.writeObject(operresult);
                        //重置操作
                        operresult.operClear();
                        // 清理资源
                        outputStream.flush();


                    }
                    //查询一个
                    else if (operresult.getOperationcode() == 004) {
                        System.out.println("查询一个");
                        System.out.println("查询: "+operresult.getUser(1).getId());
                        researchOne(operresult.getUser(1));
                        // 向客户端发送响应数据
                        outputStream.reset();
                        outputStream.writeObject(operresult);
                        //重置操作
                        operresult.operClear();
                        // 清理资源
                        outputStream.flush();


                    }
                    //删除一个
                    else if (operresult.getOperationcode() == 005) {
                        System.out.println("删除一个");
                        deleteOne(operresult.getUser(1));
                        // 向客户端发送响应数据
                        outputStream.reset();
                        outputStream.writeObject(operresult);
                        //重置操作
                        operresult.operClear();
                        // 清理资源
                        outputStream.flush();


                    }
                    //更新
                    else if (operresult.getOperationcode() == 006) {
                        System.out.println("更新");
                        updateOne(operresult.getUser(1));
                        // 向客户端发送响应数据
                        outputStream.reset();
                        outputStream.writeObject(operresult);
                        //重置操作
                        operresult.operClear();
                        // 清理资源
                        outputStream.flush();


                    }
                    //修改密码
                    else if (operresult.getOperationcode() == 007) {
                        System.out.println("修改");
                        passwordChange(operresult.getUser(1),operresult.getUser(2));
                        // 向客户端发送响应数据
                        outputStream.reset();
                        outputStream.writeObject(operresult);
                        //重置操作
                        operresult.operClear();
                        // 清理资源
                        outputStream.flush();


                    }
                    //终止操作
                    else if (operresult.getOperationcode() == -1) {
                        System.out.println("服务端终止");
                        isfinished=true;

                    }

                }

                socket.close();

            } catch (IOException | ClassNotFoundException e) {
                e.printStackTrace();
            } catch (SQLException e) {
                throw new RuntimeException(e);
            }



    }

}


