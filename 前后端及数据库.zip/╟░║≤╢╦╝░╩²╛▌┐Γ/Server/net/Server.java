package net;
import common.User;
import database.UserDao_Imp;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.sql.SQLException;
import java.util.HashMap;


public class Server {




    public static void main(String[] args) throws SQLException {


        //for(int i=1;i<=10;i++) {
            //UserDao_Imp u = new UserDao_Imp();
           // u.select("4");
            //u.select("6");
        //}
        try {
            int  port=8081;
            ServerSocket serverSocket = new ServerSocket(port);
            System.out.println("服务端已启动，等待客户端连接...");

            while (true) {
                Socket socket = serverSocket.accept();
                System.out.println("客户端已连接，地址：" + socket.getInetAddress());

                // 创建线程处理客户端请求
                ServerThread serverthread= new ServerThread(socket);
                serverthread.start();
                //用于测试
               // serverSocket.close();
            }


        } catch (IOException e) {
            e.printStackTrace();
        }

    }
    }


